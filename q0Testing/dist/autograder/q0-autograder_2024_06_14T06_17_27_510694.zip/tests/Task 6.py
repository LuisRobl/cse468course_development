OK_FORMAT = True

test = {   'name': 'Task 6',
    'points': 15,
    'suites': [   {   'cases': [   {   'code': ">>> '01' in counts_oppo and counts_oppo['01'] == 468\nTrue",
                                       'failure_message': 'EXPECTED opposites TO BE RUN 468 TIMES',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 15}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
